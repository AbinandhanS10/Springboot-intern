package org.example;

public class SpringBoot {
    public void hello() {
        System.out.println("hello from SpringBoot");
    }
}
