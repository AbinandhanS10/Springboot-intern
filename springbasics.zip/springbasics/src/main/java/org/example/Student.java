package org.example;

import java.util.ArrayList;

public class Student {
    String Name;
    public void internship(){
        System.out.println( "Day 01 of Springboot+React Internship");
    }

}
