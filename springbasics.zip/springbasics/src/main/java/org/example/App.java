package org.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ) {
        ApplicationContext context=new ClassPathXmlApplicationContext("resources.xml");
        Student s=(Student)context.getBean("st");
        s.internship();
        SpringBoot f=(SpringBoot)context.getBean("fun");
        f.hello();
        ultra u=(ultra)context.getBean("ultraraw");
        u.ultraraw();
        taskclass2 two= (taskclass2)context.getBean("tc2");
        two.print();
        taskclass3 three=(taskclass3) context.getBean("tc3");
        three.print();
    }
}
