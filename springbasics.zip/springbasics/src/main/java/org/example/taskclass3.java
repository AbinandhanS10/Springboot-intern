package org.example;

public class taskclass3 {
    public void print(){
        System.out.println("this message is from taskclass3");
    }
}
