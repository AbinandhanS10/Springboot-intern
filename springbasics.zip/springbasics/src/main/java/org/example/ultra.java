package org.example;

public class ultra {
    public void ultraraw(){
        System.out.println("this message is from class ultra");
    }
}
