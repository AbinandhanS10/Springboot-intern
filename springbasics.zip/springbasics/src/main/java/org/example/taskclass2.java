package org.example;

public class taskclass2 {
    public void print(){
        System.out.println("this message is from taskclass2");
    }
}
